\
// ============ Loader Fade ============
window.addEventListener('load',()=>{
  setTimeout(()=>document.getElementById('light-loader').style.opacity=0,2000);
  setTimeout(()=>document.getElementById('light-loader').remove(),3000);
});

// ============ Tap Gloss ============
document.querySelectorAll('section,aside').forEach(p=>{
  p.classList.add('panel');
  p.addEventListener('click',()=>{
    p.classList.add('tap');
    setTimeout(()=>p.classList.remove('tap'),800);
  });
});

// ============ State ============
const State = {
  reserve: 120,
  therm: 0.85,
  lowPower: true,
  running: true,       // auto-start
  lastTick: performance.now(),
  tickCount: 0,
  scale: 'meter',
  layers: 3,
  opacity: 0.60,
  hitIntensity: 0.15,
  tpChars: 0, tpLast: performance.now(),
  layersOn: { shield:true, switch:true, zoom:true },
  quality: 'base',
};

// Persist & restore simple settings
(function restore(){
  try{
    const raw = localStorage.getItem('light.swedishdawn');
    if(raw){
      const s = JSON.parse(raw);
      Object.assign(State, s);
      document.getElementById('scaleSel').value = State.scale;
      document.getElementById('rngLayers').value = State.layers;
      document.getElementById('layerCount').textContent = State.layers;
      document.getElementById('rngOpacity').value = Math.round(State.opacity*100);
      document.getElementById('opacityVal').textContent = State.opacity.toFixed(2);
      document.getElementById('rngHits').value = Math.round(State.hitIntensity*100);
      document.getElementById('hitRate').textContent = State.hitIntensity<0.2?'Low':(State.hitIntensity<0.6?'Med':'High');
      document.getElementById('chkShield').checked = State.layersOn.shield;
      document.getElementById('chkSwitch').checked = State.layersOn.switch;
      document.getElementById('chkZoom').checked = State.layersOn.zoom;
      document.getElementById('qualLabel').textContent = State.quality==='base'?'Base':(State.quality==='zoom'?'Extra Zoom':'Extra Range');
    }
  }catch(e){}
})();

function persist(){
  try{ localStorage.setItem('light.swedishdawn', JSON.stringify({
    scale: State.scale,
    layers: State.layers,
    opacity: State.opacity,
    hitIntensity: State.hitIntensity,
    layersOn: State.layersOn,
    quality: State.quality
  })); }catch(e){}
}

// ============ HUD Helpers ============
function setText(id,v){ document.getElementById(id).textContent = v; }
function setBar(idOrEl,pct){
  const el = typeof idOrEl==='string'?document.getElementById(idOrEl):idOrEl;
  el.style.width = Math.max(0,Math.min(100,pct))+'%';
  el.style.background = pct<60 ? 'var(--ok)' : (pct<85 ? 'var(--warn)' : 'var(--crit)');
}

// ============ Controls ============
const scaleSel = document.getElementById('scaleSel');
const rngLayers = document.getElementById('rngLayers');
const rngOpacity= document.getElementById('rngOpacity');
const rngHits   = document.getElementById('rngHits');

scaleSel.onchange = e => { State.scale = e.target.value; persist(); };
rngLayers.oninput = e => { State.layers = +e.target.value; setText('layerCount', State.layers); persist(); };
rngOpacity.oninput= e => { State.opacity = (+e.target.value)/100; setText('opacityVal', State.opacity.toFixed(2)); persist(); };
rngHits.oninput   = e => {
  const v = +e.target.value; State.hitIntensity = v/100;
  setText('hitRate', v<20?'Low':v<60?'Med':'High'); persist();
};

document.getElementById('start').onclick = ()=>{ if(!State.running){ State.running=true; requestAnimationFrame(tick);} };
document.getElementById('pause').onclick = ()=>{ State.running=false; };
document.getElementById('step').onclick  = ()=>{ if(!State.running){ stepOnce(); renderAll(); } };

// Layer Stack & Quality
const chkShield = document.getElementById('chkShield');
const chkSwitch = document.getElementById('chkSwitch');
const chkZoom   = document.getElementById('chkZoom');
chkShield.onchange = ()=>{ State.layersOn.shield = chkShield.checked; persist(); };
chkSwitch.onchange = ()=>{ State.layersOn.switch = chkSwitch.checked; persist(); };
chkZoom.onchange   = ()=>{ State.layersOn.zoom   = chkZoom.checked; persist(); };

const qualLabel = document.getElementById('qualLabel');
document.getElementById('qBase').onclick  = ()=>{ State.quality='base';  qualLabel.textContent='Base'; persist(); };
document.getElementById('qZoom').onclick  = ()=>{ State.quality='zoom';  qualLabel.textContent='Extra Zoom'; persist(); };
document.getElementById('qRange').onclick = ()=>{ State.quality='range'; qualLabel.textContent='Extra Range'; persist(); };

// Modular Activation
const Modules = {
  active:{},
  activate(key){
    if(this.active[key]) return;
    this.active[key]=true;
    if(key==='bridgeVerify'){
      State.reserve += 8;
    } else if(key==='shieldDome'){
      State.layers = Math.min(8, State.layers+1);
      rngLayers.value = State.layers; setText('layerCount', State.layers);
    } else if(key==='compressor'){
      State.reserve += 4; State.therm = Math.min(1, State.therm+0.03);
    } else if(key==='governor'){
      State.lowPower = false; document.getElementById('mode').textContent='FULL'; setBar('barMode',85);
    } else if(key==='switchField'){
      State.layersOn.switch = true; chkSwitch.checked = true;
    } else if(key==='angleZoom'){
      State.layersOn.zoom = true; chkZoom.checked = true;
    }
    persist();
  }
};
document.querySelectorAll('#activationBox button[data-mod]').forEach(btn=>{
  btn.onclick = () => Modules.activate(btn.getAttribute('data-mod'));
});

// ============ Keyboard Shortcuts ============
window.addEventListener('keydown', e=>{
  const k = e.key.toLowerCase();
  if(k===' '){ e.preventDefault(); State.running = !State.running; if(State.running) requestAnimationFrame(tick); return; }
  if(k==='1'){ chkShield.checked=!chkShield.checked; chkShield.onchange(); }
  if(k==='2'){ chkSwitch.checked=!chkSwitch.checked; chkSwitch.onchange(); }
  if(k==='3'){ chkZoom.checked=!chkZoom.checked; chkZoom.onchange(); }
  if(k==='z'){ document.getElementById('qBase').click(); }
  if(k==='x'){ document.getElementById('qZoom').click(); }
  if(k==='c'){ document.getElementById('qRange').click(); }
  if(k==='+'){ State.layers = Math.min(8, State.layers+1); rngLayers.value=State.layers; setText('layerCount', State.layers); persist(); }
  if(k==='-'){ State.layers = Math.max(1, State.layers-1); rngLayers.value=State.layers; setText('layerCount', State.layers); persist(); }
  if(k==='['){ State.hitIntensity=Math.max(0, State.hitIntensity-0.05); rngHits.value=Math.round(State.hitIntensity*100); setText('hitRate', State.hitIntensity<0.2?'Low':State.hitIntensity<0.6?'Med':'High'); persist(); }
  if(k===']'){ State.hitIntensity=Math.min(1, State.hitIntensity+0.05); rngHits.value=Math.round(State.hitIntensity*100); setText('hitRate', State.hitIntensity<0.2?'Low':State.hitIntensity<0.6?'Med':'High'); persist(); }
  if(k==='o'){ State.lowPower = !State.lowPower; document.getElementById('mode').textContent = State.lowPower?'LOW-POWER':'FULL'; setBar('barMode', State.lowPower?33:85); }
});

// ============ Text Runtime ============
const laneOut = document.getElementById('laneOut');
function appendTextLine(s){
  laneOut.textContent += s + '\\n';
  if(laneOut.textContent.length>2600) laneOut.textContent = laneOut.textContent.slice(-1800);
  State.tpChars += s.length;
}

// ============ Mini Shield ============
const miniCanvas = document.getElementById('miniCanvas');
const mctx = miniCanvas.getContext('2d');
function resizeMini(){ miniCanvas.width = miniCanvas.clientWidth; miniCanvas.height=160; }
window.addEventListener('resize', resizeMini); resizeMini();

let hits = [];
function spawnHit(){
  const w=miniCanvas.width,h=miniCanvas.height;
  const edge = Math.floor(Math.random()*4);
  let x=0,y=0;
  if(edge===0){ x=0; y=Math.random()*h; }
  if(edge===1){ x=w; y=Math.random()*h; }
  if(edge===2){ x=Math.random()*w; y=0; }
  if(edge===3){ x=Math.random()*w; y=h; }
  hits.push({x,y,r:1,life:1.0});
}
function scaleRadius(base){ return State.scale==='meter' ? base : base*1.8; }

function renderMini(){
  const w=miniCanvas.width,h=miniCanvas.height, cx=w*0.5, cy=h*0.6;
  mctx.clearRect(0,0,w,h);
  const sky = mctx.createLinearGradient(0,0,0,h);
  sky.addColorStop(0, 'rgba(255,255,255,0.95)');
  sky.addColorStop(1, 'rgba(240,247,255,0.85)');
  mctx.fillStyle = sky; mctx.fillRect(0,0,w,h);

  const coreR = scaleRadius(14 + State.reserve/18);
  const hue = 210 - State.therm*40;
  const core = mctx.createRadialGradient(cx,cy,0,cx,cy,coreR);
  core.addColorStop(0, `hsla(${hue},85%,70%,0.75)`);
  core.addColorStop(1, `hsla(${hue},85%,70%,0.00)`);
  mctx.fillStyle = core; mctx.beginPath(); mctx.arc(cx,cy, coreR, 0, Math.PI*2); mctx.fill();

  for(let i=0;i<State.layers;i++){
    const r = scaleRadius(coreR + 12 + i*11);
    const a = State.opacity*(0.85 - i*0.07);
    mctx.strokeStyle = `rgba(90,160,255,${a})`;
    mctx.lineWidth = 2;
    mctx.beginPath(); mctx.arc(cx,cy,r,0,Math.PI*2); mctx.stroke();
  }

  if(Math.random() < State.hitIntensity*0.6){ spawnHit(); }
  hits.forEach(hh=>{
    const dx=cx-hh.x, dy=cy-hh.y, d=Math.max(0.0001, Math.hypot(dx,dy));
    const step = 0.7 + State.hitIntensity*1.3;
    hh.x += (dx/d)*step; hh.y += (dy/d)*step; hh.r += 0.55; hh.life -= 0.012;

    mctx.strokeStyle='rgba(180,180,180,0.65)';
    mctx.beginPath(); mctx.arc(hh.x,hh.y,2+hh.r*0.2,0,Math.PI*2); mctx.stroke();

    const dist = Math.hypot(hh.x-cx, hh.y-cy);
    for(let i=State.layers-1;i>=0;i--){
      const rr = scaleRadius(coreR + 12 + i*11);
      if(dist <= rr+2 && dist >= rr-2){
        State.reserve = Math.min(220, State.reserve + 0.5);
        mctx.strokeStyle='rgba(120,190,255,0.9)';
        mctx.lineWidth=3;
        mctx.beginPath(); mctx.arc(cx,cy,rr,0,Math.PI*2); mctx.stroke();
        hh.life = 0; break;
      }
    }
  });
  hits = hits.filter(h=>h.life>0);

  mctx.strokeStyle = 'rgba(160,180,210,0.35)';
  for(let i=0;i<3;i++){
    const y = cy - 40 + (i*18);
    const len = 40 + Math.sin(State.tickCount/30+i)*22;
    mctx.beginPath(); mctx.moveTo(cx-60,y); mctx.lineTo(cx-60+len,y+Math.random()*2-1); mctx.stroke();
  }
}

// ============ Switch-Field ============
const switchCanvas = document.getElementById('switchField');
const sctx = switchCanvas.getContext('2d');
function resizeSwitch(){ switchCanvas.width = switchCanvas.clientWidth; switchCanvas.height=160; }
window.addEventListener('resize', resizeSwitch); resizeSwitch();

function renderSwitchField(){
  const w=switchCanvas.width,h=switchCanvas.height;
  sctx.clearRect(0,0,w,h);
  const sky = sctx.createLinearGradient(0,0,0,h);
  sky.addColorStop(0,'rgba(255,255,255,0.95)');
  sky.addColorStop(1,'rgba(245,250,255,0.9)');
  sctx.fillStyle = sky; sctx.fillRect(0,0,w,h);

  if(!State.layersOn.switch) return;

  const cx=w*0.5, cy=h*0.55;
  const baseR = 36 + State.reserve*0.28;
  const hue = 190 - State.therm*20;

  const steps = (State.quality==='range') ? 540 : 360;
  const rings = (State.quality==='range') ? 2 : 1;

  for(let ring=0; ring<rings; ring++){
    const ringR = baseR + ring*18;
    for(let i=0;i<steps;i++){
      const theta = (i/steps)*Math.PI*2;
      const jitter = Math.sin(theta*4 + State.tickCount*0.05)*(2+ring);
      const r = ringR + jitter;
      const x = cx + r*Math.cos(theta);
      const y = cy + r*Math.sin(theta);
      const a = 0.18 + 0.28*Math.max(0,Math.sin(theta*2 + State.tickCount*0.03));
      sctx.fillStyle = `hsla(${hue},70%,55%,${a})`;
      sctx.fillRect(x, y, 1.1, 1.1);
    }
  }

  const spokes = (State.quality==='zoom') ? 24 : 12;
  sctx.strokeStyle = `hsla(${hue},70%,45%,0.12)`;
  sctx.lineWidth = 1;
  for(let k=0;k<spokes;k++){
    const th = (k/spokes)*Math.PI*2 + State.tickCount*0.005;
    sctx.beginPath();
    sctx.moveTo(cx,cy);
    sctx.lineTo(cx + (baseR+22)*Math.cos(th), cy + (baseR+22)*Math.sin(th));
    sctx.stroke();
  }
}

// ============ Angle Zoom ============
const zoomCanvas = document.getElementById('angleZoom');
const zctx = zoomCanvas.getContext('2d');
function resizeZoom(){ zoomCanvas.width = zoomCanvas.clientWidth; zoomCanvas.height=160; }
window.addEventListener('resize', resizeZoom); resizeZoom();

let channels = Array.from({length:10}, ()=>Math.random());
function aiRemap(){
  const next = [];
  for(let i=0;i<channels.length;i++){
    next.push(channels[i]);
    next.push((channels[i]+channels[(i+1)%channels.length])/2);
  }
  channels = next.slice(0,10).map(v=> (v*0.7 + Math.random()*0.3));
}

function renderAngleZoom(){
  const w=zoomCanvas.width,h=zoomCanvas.height;
  zctx.clearRect(0,0,w,h);
  const bg = zctx.createLinearGradient(0,0,0,h);
  bg.addColorStop(0,'rgba(255,255,255,0.95)');
  bg.addColorStop(1,'rgba(245,248,252,0.9)');
  zctx.fillStyle = bg; zctx.fillRect(0,0,w,h);

  if(!State.layersOn.zoom) return;

  const cx=w*0.16, cy=h*0.5;
  const sectorDeg = (State.quality==='zoom') ? 28 : 16;
  const startDeg = (State.tickCount*0.4) % 360;

  zctx.strokeStyle='rgba(160,170,185,0.22)';
  zctx.lineWidth=1.2;
  zctx.beginPath();
  zctx.moveTo(cx,cy);
  const r= h*0.44;
  const a0=(startDeg- sectorDeg/2)*Math.PI/180;
  const a1=(startDeg+ sectorDeg/2)*Math.PI/180;
  zctx.arc(cx,cy,r,a0,a1);
  zctx.closePath(); zctx.stroke();

  zctx.lineWidth = 1.5;
  for(let i=0;i<10;i++){
    const t = i/9;
    const th = (startDeg - sectorDeg/2 + t*sectorDeg) * Math.PI/180;
    const amp = (0.42 + channels[i]*0.58) * r;
    zctx.strokeStyle = `rgba(120,130,150,${0.30 + channels[i]*0.45})`;
    zctx.beginPath();
    zctx.moveTo(cx,cy);
    zctx.lineTo(cx + amp*Math.cos(th), cy + amp*Math.sin(th));
    zctx.stroke();

    zctx.fillStyle = `rgba(120,130,150,${0.18 + channels[i]*0.55})`;
    zctx.beginPath();
    zctx.arc(cx + amp*Math.cos(th), cy + amp*Math.sin(th), 2, 0, Math.PI*2);
    zctx.fill();
  }

  zctx.strokeStyle='rgba(130,160,190,0.06)';
  zctx.lineWidth=1;
  for(let gy=20; gy<h; gy+=20){ zctx.beginPath(); zctx.moveTo(0,gy); zctx.lineTo(w,gy); zctx.stroke(); }
}

// ============ Runtime ============
function stepOnce(){
  const cost = State.lowPower ? 0.25 : 0.65;
  const leak = 0.18;
  const recover = 0.12 + State.layers*0.02;
  State.reserve = Math.max(0, Math.min(220, State.reserve - cost - leak + recover));
  State.therm   = Math.max(0.25, Math.min(1.0, State.therm - cost*0.002 + 0.0018));

  setText('reserve', State.reserve.toFixed(1)); setBar('barRes', (State.reserve/2.2));
  setText('therm', Math.round(State.therm*100)+'%'); setBar('barTherm', State.therm*100);
  document.getElementById('mode').textContent = State.lowPower?'LOW-POWER':'FULL';

  if(Math.random()<0.6) appendTextLine(`tick ${State.tickCount} :: reserve=${State.reserve.toFixed(1)} therm=${(State.therm*100|0)}% layers=${State.layers}`);
  const now=performance.now();
  if(now-State.tpLast>1000){ setText('tp', State.tpChars); State.tpChars=0; State.tpLast=now; }
}

function renderAll(){
  if(State.layersOn.shield) renderMini(); else mctx.clearRect(0,0,miniCanvas.width,miniCanvas.height);
  renderSwitchField();
  renderAngleZoom();
}

function tick(){
  if(!State.running) return;
  State.tickCount++;
  if(State.tickCount % 15 === 0) aiRemap();
  stepOnce();
  renderAll();
  requestAnimationFrame(tick);
}

// Init
setText('reserve', State.reserve.toFixed(1)); setBar('barRes', (State.reserve/2.2));
setText('therm', Math.round(State.therm*100)+'%'); setBar('barTherm', State.therm*100);
requestAnimationFrame(tick);
