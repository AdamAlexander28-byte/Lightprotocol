import { sql } from "drizzle-orm";
import { pgTable, text, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Database schema (for potential future use)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// .LIGHT Swedish Dawn - Type Definitions

export interface LightState {
  reserve: number;
  therm: number;
  lowPower: boolean;
  running: boolean;
  lastTick: number;
  tickCount: number;
  scale: 'meter' | 'planetary';
  layers: number;
  opacity: number;
  hitIntensity: number;
  tpChars: number;
  tpLast: number;
  layersOn: {
    shield: boolean;
    switch: boolean;
    zoom: boolean;
  };
  quality: 'base' | 'zoom' | 'range';
}

export interface Hit {
  x: number;
  y: number;
  r: number;
  life: number;
}

export interface ModuleState {
  [key: string]: boolean;
}

export type ModuleKey = 
  | 'bridgeVerify' 
  | 'shieldDome' 
  | 'compressor' 
  | 'governor' 
  | 'switchField' 
  | 'angleZoom';

export interface PersistedSettings {
  scale: 'meter' | 'planetary';
  layers: number;
  opacity: number;
  hitIntensity: number;
  layersOn: {
    shield: boolean;
    switch: boolean;
    zoom: boolean;
  };
  quality: 'base' | 'zoom' | 'range';
}
