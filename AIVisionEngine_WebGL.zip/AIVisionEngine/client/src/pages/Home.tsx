import LightViz from './LightViz';

export default function Home() {
  return <LightViz />;
}
