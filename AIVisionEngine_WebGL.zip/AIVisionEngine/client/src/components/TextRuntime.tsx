import { useEffect, useRef } from 'react';
import type { LightState } from '@shared/schema';

interface TextRuntimeProps {
  state: LightState;
  throughput: number;
}

export function TextRuntime({ state, throughput }: TextRuntimeProps) {
  const laneRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!laneRef.current) return;
    
    if (Math.random() < 0.6) {
      const line = `tick ${state.tickCount} :: reserve=${state.reserve.toFixed(1)} therm=${Math.round(state.therm * 100)}% layers=${state.layers}`;
      
      const currentText = laneRef.current.textContent || '';
      const newText = currentText + line + '\n';
      
      laneRef.current.textContent = newText.length > 2600 
        ? newText.slice(-1800) 
        : newText;
    }
  }, [state.tickCount, state.reserve, state.therm, state.layers]);

  return (
    <div className="flex flex-col gap-2.5 overflow-hidden">
      <div className="flex items-center justify-between">
        <span className="font-semibold">Transistor Lanes</span>
        <span className="text-xs" style={{ color: 'rgba(0, 0, 0, 0.55)' }}>
          Throughput: <span id="tp" data-testid="text-throughput">{throughput}</span> chars/s
        </span>
      </div>
      
      <div 
        id="lanes" 
        className="grid h-full gap-1.5 overflow-auto rounded-lg bg-[rgba(255,255,255,0.35)] p-2"
        style={{ gridTemplateColumns: '1fr' }}
      >
        <div className="min-h-[54px] rounded-lg border border-[rgba(200,210,230,0.6)] bg-[rgba(255,255,255,0.55)] p-2 font-mono text-xs whitespace-pre-wrap">
          <h4 className="mb-1 mt-0 text-xs" style={{ color: 'rgb(106, 166, 255)' }}>Lane T0</h4>
          <div id="laneOut" ref={laneRef} className="out" data-testid="text-lane-output" />
        </div>
      </div>
    </div>
  );
}
