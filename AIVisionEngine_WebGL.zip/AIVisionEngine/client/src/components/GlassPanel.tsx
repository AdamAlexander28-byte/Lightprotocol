import { useState, type ReactNode, type CSSProperties } from 'react';

interface GlassPanelProps {
  children: ReactNode;
  className?: string;
  id?: string;
  ariaLabel?: string;
  style?: CSSProperties;
}

export function GlassPanel({ children, className = '', id, ariaLabel, style }: GlassPanelProps) {
  const [tapped, setTapped] = useState(false);

  const handleClick = () => {
    setTapped(true);
    setTimeout(() => setTapped(false), 800);
  };

  return (
    <section
      id={id}
      className={`relative overflow-hidden rounded-lg border border-[rgba(200,210,230,0.3)] bg-[rgba(255,255,255,0.35)] p-3 shadow-glass backdrop-blur-glass ${className}`}
      onClick={handleClick}
      aria-label={ariaLabel}
      style={style}
      data-testid={id ? `panel-${id}` : undefined}
    >
      {children}
      
      {/* Tap Gloss Effect */}
      <div
        className={`pointer-events-none absolute inset-0 transition-transform duration-700 ease-out ${
          tapped ? 'translate-x-full' : '-translate-x-full'
        }`}
        style={{
          background: 'linear-gradient(120deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.6) 50%, rgba(255,255,255,0) 100%)',
        }}
      />
    </section>
  );
}
