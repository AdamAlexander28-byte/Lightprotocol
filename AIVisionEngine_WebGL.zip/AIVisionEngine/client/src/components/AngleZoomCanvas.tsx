import { useEffect, useRef } from 'react';
import type { LightState } from '@shared/schema';

interface AngleZoomCanvasProps {
  state: LightState;
  channels: number[];
}

export function AngleZoomCanvas({ state, channels }: AngleZoomCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width;
      canvas.height = 160;
    };

    resize();
    window.addEventListener('resize', resize);

    return () => window.removeEventListener('resize', resize);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;

    ctx.clearRect(0, 0, w, h);

    // Background gradient
    const bg = ctx.createLinearGradient(0, 0, 0, h);
    bg.addColorStop(0, 'rgba(255,255,255,0.95)');
    bg.addColorStop(1, 'rgba(245,248,252,0.9)');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);

    if (!state.layersOn.zoom) return;

    const cx = w * 0.16;
    const cy = h * 0.5;
    const sectorDeg = state.quality === 'zoom' ? 28 : 16;
    const startDeg = (state.tickCount * 0.4) % 360;

    // Sector outline
    ctx.strokeStyle = 'rgba(160,170,185,0.22)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    const r = h * 0.44;
    const a0 = (startDeg - sectorDeg / 2) * Math.PI / 180;
    const a1 = (startDeg + sectorDeg / 2) * Math.PI / 180;
    ctx.arc(cx, cy, r, a0, a1);
    ctx.closePath();
    ctx.stroke();

    // Channel rays
    ctx.lineWidth = 1.5;
    for (let i = 0; i < 10; i++) {
      const t = i / 9;
      const th = (startDeg - sectorDeg / 2 + t * sectorDeg) * Math.PI / 180;
      const amp = (0.42 + channels[i] * 0.58) * r;
      ctx.strokeStyle = `rgba(120,130,150,${0.30 + channels[i] * 0.45})`;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + amp * Math.cos(th), cy + amp * Math.sin(th));
      ctx.stroke();

      ctx.fillStyle = `rgba(120,130,150,${0.18 + channels[i] * 0.55})`;
      ctx.beginPath();
      ctx.arc(cx + amp * Math.cos(th), cy + amp * Math.sin(th), 2, 0, Math.PI * 2);
      ctx.fill();
    }

    // Grid lines
    ctx.strokeStyle = 'rgba(130,160,190,0.06)';
    ctx.lineWidth = 1;
    for (let gy = 20; gy < h; gy += 20) {
      ctx.beginPath();
      ctx.moveTo(0, gy);
      ctx.lineTo(w, gy);
      ctx.stroke();
    }
  }, [state, channels]);

  return (
    <div id="zoomBox" className="rounded-[10px] border border-[rgba(200,210,230,0.3)] bg-[rgba(255,255,255,0.25)] p-2.5 shadow-glass-sm backdrop-blur-glass-sm">
      <canvas 
        ref={canvasRef} 
        id="angleZoom"
        className="block h-[160px] w-full rounded-lg bg-[rgba(255,255,255,0.9)]"
        data-testid="canvas-zoom"
      />
      <div id="zoomLegend" className="mt-1.5 text-[11px] leading-relaxed" style={{ color: 'rgba(0, 0, 0, 0.55)' }}>
        • Magnified sector with 0–9 micro-channels. "Extra Zoom" increases sector resolution.
      </div>
    </div>
  );
}
