import type { LightState } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface ShieldControlsProps {
  state: LightState;
  onUpdate: (updates: Partial<LightState>) => void;
  onStart: () => void;
  onPause: () => void;
  onStep: () => void;
}

function Pill({ children, testId }: { children: React.ReactNode; testId?: string }) {
  return (
    <span 
      className="inline-block rounded-full border border-[rgba(180,190,210,0.4)] bg-[rgba(255,255,255,0.25)] px-2 py-1 text-[11px]" 
      style={{ color: 'rgb(14, 26, 43)' }}
      data-testid={testId}
    >
      {children}
    </span>
  );
}

export function ShieldControls({ state, onUpdate, onStart, onPause, onStep }: ShieldControlsProps) {
  const getHitRateLabel = (intensity: number) => {
    if (intensity < 0.2) return 'Low';
    if (intensity < 0.6) return 'Med';
    return 'High';
  };

  return (
    <div className="mt-3.5">
      <h3 className="mb-2.5 mt-1.5 text-base font-semibold" style={{ color: 'rgb(14, 26, 43)' }}>Shield Controls</h3>
      
      {/* Scale */}
      <div className="mb-1.5 flex items-center justify-between">
        <span className="text-sm">Scale</span>
        <Select value={state.scale} onValueChange={(value) => onUpdate({ scale: value as 'meter' | 'planetary' })}>
          <SelectTrigger className="w-[140px] h-7 text-xs" data-testid="select-scale">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="meter">Meter (local)</SelectItem>
            <SelectItem value="planetary">Planetary</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Layers */}
      <div className="mb-1.5 mt-1.5 flex items-center justify-between">
        <span className="text-sm">Layers</span>
        <Pill testId="text-layer-count">{state.layers}</Pill>
      </div>
      <Slider
        value={[state.layers]}
        onValueChange={([value]) => onUpdate({ layers: value })}
        min={1}
        max={8}
        step={1}
        className="w-full"
        aria-label="Layers"
        data-testid="input-layers"
      />

      {/* Opacity */}
      <div className="mb-1.5 mt-2 flex items-center justify-between">
        <span className="text-sm">Opacity</span>
        <Pill testId="text-opacity">{state.opacity.toFixed(2)}</Pill>
      </div>
      <Slider
        value={[Math.round(state.opacity * 100)]}
        onValueChange={([value]) => onUpdate({ opacity: value / 100 })}
        min={10}
        max={100}
        step={1}
        className="w-full"
        aria-label="Opacity"
        data-testid="input-opacity"
      />

      {/* Hit Rate */}
      <div className="mb-1.5 mt-2 flex items-center justify-between">
        <span className="text-sm">Hit Rate</span>
        <Pill testId="text-hit-rate">{getHitRateLabel(state.hitIntensity)}</Pill>
      </div>
      <Slider
        value={[Math.round(state.hitIntensity * 100)]}
        onValueChange={([value]) => onUpdate({ hitIntensity: value / 100 })}
        min={0}
        max={100}
        step={1}
        className="w-full"
        aria-label="Hit rate"
        data-testid="input-hit-rate"
      />

      {/* Control Buttons */}
      <div className="mt-2.5 flex gap-2">
        <Button
          onClick={onStart}
          className="flex-1 text-white"
          style={{ background: 'rgb(140, 201, 255)', borderColor: 'rgb(120, 181, 235)' }}
          data-testid="button-start"
        >
          Start
        </Button>
        <Button
          onClick={onPause}
          className="flex-1 text-white"
          style={{ background: 'rgb(140, 201, 255)', borderColor: 'rgb(120, 181, 235)' }}
          data-testid="button-pause"
        >
          Pause
        </Button>
        <Button
          onClick={onStep}
          className="flex-1 text-white"
          style={{ background: 'rgb(140, 201, 255)', borderColor: 'rgb(120, 181, 235)' }}
          data-testid="button-step"
        >
          Step
        </Button>
      </div>
    </div>
  );
}
