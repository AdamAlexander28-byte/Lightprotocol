import { useEffect, useState } from 'react';

export function LightLoader() {
  const [opacity, setOpacity] = useState(1);
  const [removed, setRemoved] = useState(false);

  useEffect(() => {
    const fadeTimer = setTimeout(() => setOpacity(0), 2000);
    const removeTimer = setTimeout(() => setRemoved(true), 3000);
    return () => {
      clearTimeout(fadeTimer);
      clearTimeout(removeTimer);
    };
  }, []);

  if (removed) return null;

  return (
    <div 
      className="fixed inset-0 z-[9999] flex flex-col items-center justify-center overflow-hidden transition-opacity duration-1000"
      style={{ 
        opacity,
        background: 'linear-gradient(to top, #eaf3ff 0%, #ffffff 100%)',
      }}
      aria-hidden="true"
    >
      {/* Sun */}
      <div 
        className="w-[200px] h-[200px] rounded-full animate-pulse-sun"
        style={{
          background: 'radial-gradient(circle at 50% 60%, rgba(255,255,240,0.9) 0%, rgba(255,255,255,0) 80%)',
        }}
      />
      
      {/* Haze */}
      <div 
        className="absolute w-[200%] h-full animate-dawn-sweep"
        style={{
          background: 'linear-gradient(120deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.5) 50%, rgba(255,255,255,0) 100%)',
        }}
      />
      
      {/* Text */}
      <div 
        className="mt-6 text-base tracking-wider"
        style={{ color: '#202a3c' }}
        role="status"
      >
        .LIGHT — Warming circuits at dawn…
      </div>
    </div>
  );
}
