import type { ModuleKey, ModuleState } from '@shared/schema';
import { Button } from '@/components/ui/button';

interface ModularActivationProps {
  moduleState: ModuleState;
  onActivate: (key: ModuleKey) => void;
}

interface ModuleConfig {
  key: ModuleKey;
  label: string;
}

const modules: ModuleConfig[] = [
  { key: 'bridgeVerify', label: 'Bridge: Verification' },
  { key: 'shieldDome', label: 'Shield: Planetary Dome' },
  { key: 'compressor', label: 'Compressor: Delta Seeds' },
  { key: 'governor', label: 'Governor: Burst/Coast' },
  { key: 'switchField', label: 'Switch-Field Layer' },
  { key: 'angleZoom', label: 'Angle Zoom Layer' },
];

export function ModularActivation({ moduleState, onActivate }: ModularActivationProps) {
  return (
    <div
      id="activationBox"
      className="mt-2.5 rounded-[10px] border border-[rgba(200,210,230,0.3)] bg-[rgba(255,255,255,0.25)] p-2.5 shadow-glass-sm backdrop-blur-glass-sm"
      aria-label="Modular Activation"
      data-testid="panel-modular-activation"
    >
      <h4 className="m-0 mb-1.5 text-sm font-semibold" style={{ color: 'rgb(14, 26, 43)' }}>
        Modular Activation
      </h4>
      
      {modules.map((module) => (
        <div key={module.key} className="mb-1.5 flex items-center justify-between">
          <span className="text-xs" style={{ color: 'rgb(44, 61, 85)' }}>{module.label}</span>
          <Button
            onClick={() => onActivate(module.key)}
            disabled={moduleState[module.key]}
            size="sm"
            className="text-xs text-white"
            style={{ background: 'rgb(140, 201, 255)', borderColor: 'rgb(120, 181, 235)' }}
            data-testid={`button-activate-${module.key}`}
          >
            {moduleState[module.key] ? 'Active' : 'Activate'}
          </Button>
        </div>
      ))}
      
      <div className="mt-2 text-[11px]" style={{ color: 'rgba(0, 0, 0, 0.55)' }}>
        Add more by appending a <code className="rounded bg-black/5 px-1">.mod</code> row + handler in module activation.
      </div>
    </div>
  );
}
