import { useState, useEffect, useCallback } from 'react';
import type { LightState, PersistedSettings, ModuleKey, ModuleState } from '@shared/schema';

const STORAGE_KEY = 'light.swedishdawn';

const defaultState: LightState = {
  reserve: 120,
  therm: 0.85,
  lowPower: true,
  running: true,
  lastTick: performance.now(),
  tickCount: 0,
  scale: 'meter',
  layers: 3,
  opacity: 0.60,
  hitIntensity: 0.15,
  tpChars: 0,
  tpLast: performance.now(),
  layersOn: { shield: true, switch: true, zoom: true },
  quality: 'base',
};

export function useLightState() {
  const [state, setState] = useState<LightState>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const persisted: PersistedSettings = JSON.parse(stored);
        return { ...defaultState, ...persisted };
      }
    } catch (e) {
      console.error('Failed to load state from localStorage', e);
    }
    return defaultState;
  });

  const [moduleState, setModuleState] = useState<ModuleState>({});

  const persistSettings = useCallback((newState: LightState) => {
    try {
      const settings: PersistedSettings = {
        scale: newState.scale,
        layers: newState.layers,
        opacity: newState.opacity,
        hitIntensity: newState.hitIntensity,
        layersOn: newState.layersOn,
        quality: newState.quality,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
    } catch (e) {
      console.error('Failed to persist settings', e);
    }
  }, []);

  const updateState = useCallback((updates: Partial<LightState>) => {
    setState(prev => {
      const newState = { ...prev, ...updates };
      persistSettings(newState);
      return newState;
    });
  }, [persistSettings]);

  const activateModule = useCallback((key: ModuleKey) => {
    if (moduleState[key]) return;

    setModuleState(prev => ({ ...prev, [key]: true }));

    switch (key) {
      case 'bridgeVerify':
        setState(prev => ({ ...prev, reserve: prev.reserve + 8 }));
        break;
      case 'shieldDome':
        setState(prev => ({ 
          ...prev, 
          layers: Math.min(8, prev.layers + 1) 
        }));
        break;
      case 'compressor':
        setState(prev => ({ 
          ...prev, 
          reserve: prev.reserve + 4,
          therm: Math.min(1, prev.therm + 0.03)
        }));
        break;
      case 'governor':
        updateState({ lowPower: false });
        break;
      case 'switchField':
        updateState({ layersOn: { ...state.layersOn, switch: true } });
        break;
      case 'angleZoom':
        updateState({ layersOn: { ...state.layersOn, zoom: true } });
        break;
    }
  }, [moduleState, state.layersOn, updateState]);

  return {
    state,
    updateState,
    moduleState,
    activateModule,
  };
}
