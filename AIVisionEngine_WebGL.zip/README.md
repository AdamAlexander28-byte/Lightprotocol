# .LIGHT PROTOCOL — AIVisionEngine (WebGL Build)

**Swedish Dawn Boot** — WebGL-powered intro: gradient shader, diagonal light sweep, panel-edge reflections, subtle scanlines, plus shimmering title text.  
Auto-starts the engine after **~4 seconds**. Fully PWA-enabled and iPhone 16 Plus–ready.

## Deploy (GitHub Pages)
1. Create a repository and place all files from this folder at the root of the repo.
2. Settings → Pages → Deploy from **Main** branch → **/(root)**.
3. Open the published URL in **Safari** on your iPhone.

## Deploy (Netlify)
1. Drag the unzipped folder into the Netlify UI, or use `netlify deploy`.
2. Open the Netlify site in **Safari** on your iPhone.

## Install to Home Screen (iPhone)
1. Open your site in Safari.
2. Tap **Share** → **Add to Home Screen**.
3. Launch from the icon for full-screen, native-like mode.

## Offline
A service worker caches core assets after first load. To update, bump the cache name in `service-worker.js`.

## Customise
- Boot time: search for `4000` ms in `index.html`.
- WebGL shader: edit the fragment shader in `index.html` (look for `const fs =`).
- Title: search for "Initialising AIVision Engine".

**Created by Adam Alexander — .LIGHT Protocol**